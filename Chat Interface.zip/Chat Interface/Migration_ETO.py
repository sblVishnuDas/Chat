import pymysql
import pandas as pd
import logging

# Set up logging
logging.basicConfig(
    filename=r'D:\Python 21 01 2025\ETO_Report_Final\migrate19.txt',
    level=logging.DEBUG,
    format='%(asctime)s - %(levelname)s - %(message)s'
)

# MySQL connection details
host = 'localhost'
user = 'root'
password = 'Password123'
database = 'eto'

# Path to the cleaned CSV file
csv_file = r'D:\Python 21 01 2025\ETO_Report_Final\output6_Mar.csv'

try:
    # Read the cleaned CSV file using pandas
    data = pd.read_csv(csv_file)
    logging.debug(f"Columns in the data: {data.columns.tolist()}")

    # Handle missing values in the DataFrame before inserting into MySQL
    for column in data.columns:
        if data[column].dtype == 'object':  # For string-like columns
            data[column] = data[column].fillna('None')
        elif pd.api.types.is_numeric_dtype(data[column]):  # For numeric columns
            data[column] = data[column].fillna(0)

    # Convert the cleaned data to a list of tuples for batch insertion
    data_tuples = [tuple(row) for row in data.itertuples(index=False)]

    # Connect to the MySQL database
    conn = pymysql.connect(
        host=host,
        user=user,
        password=password,
        database=database
    )

    if conn.open:
        logging.debug('Connected to MySQL database')
        cursor = conn.cursor()

        # Insert data into the Employees table
        employees_query = """
            INSERT INTO Employees (psn, associate_name, experience, tl_name, manager)
            VALUES (%s, %s, %s, %s, %s)
            ON DUPLICATE KEY UPDATE
                associate_name=VALUES(associate_name),
                experience=VALUES(experience),
                tl_name=VALUES(tl_name),
                manager=VALUES(manager)
        """
        employees_data = [(row['psn'], row['associate_name'], row['experience'], row['tl_name'], row['manager'])
                          for _, row in data.iterrows()]
        cursor.executemany(employees_query, employees_data)

        # Insert data into the Processes table
        processes_query = """
            INSERT INTO Processes (process_code, process_name)
            VALUES (%s, %s)
            ON DUPLICATE KEY UPDATE
                process_name=VALUES(process_name)
        """
        processes_data = [(row['process_code'], row['process_name']) for _, row in data.iterrows()]
        cursor.executemany(processes_query, processes_data)

        # Insert data into the Projects table
        projects_query = """
            INSERT INTO Projects (project_code, project_name)
            VALUES (%s, %s)
            ON DUPLICATE KEY UPDATE
                project_name=VALUES(project_name)
        """
        projects_data = [(row['project_code'], row['project_name']) for _, row in data.iterrows()]
        cursor.executemany(projects_query, projects_data)

        # Insert data into the Locations table
        locations_query = """
            INSERT INTO Locations (location_code, location_name)
            VALUES (%s, %s)
            ON DUPLICATE KEY UPDATE
                location_name=VALUES(location_name)
        """
        locations_data = [(row['location_code'], row['location_name']) for _, row in data.iterrows()]
        cursor.executemany(locations_query, locations_data)

        # Insert data into the DailyData table
        daily_data_query = """
            INSERT INTO DailyData (
                psn, process_code, project_code, location_code, cr_date,
                actual_production, achievement_percent, target_revenue_inr,
                actual_revenue_inr, revenue_achievement_percent, eto_in_usd, achieved_etos, pe_code
            )
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            ON DUPLICATE KEY UPDATE
                achievement_percent=VALUES(achievement_percent),
                target_revenue_inr=VALUES(target_revenue_inr),
                actual_revenue_inr=VALUES(actual_revenue_inr),
                revenue_achievement_percent=VALUES(revenue_achievement_percent),
                eto_in_usd=VALUES(eto_in_usd),
                achieved_etos=VALUES(achieved_etos),
                pe_code=VALUES(pe_code)
                
        """
        daily_data = [
            (
                row['psn'], row['process_code'], row['project_code'], row['location_code'], row['cr_date'],
                row['actual_production'], row['achievement_percent'], row['target_revenue_inr'],
                row['actual_revenue_inr'], row['revenue_achievement_percent'], row['eto_in_usd'], row['achieved_etos'], row['pe_code']
            )
            for _, row in data.iterrows()
        ]
        cursor.executemany(daily_data_query, daily_data)

        # Commit the changes
        conn.commit()
        logging.debug(f"{len(data)} rows inserted into the tables.")

except pymysql.MySQLError as e:
    logging.error(f"MySQL Error: {e}")
except Exception as e:
    logging.error(f"General Error: {e}")
finally:
    if 'conn' in locals() and conn.open:
        cursor.close()
        conn.close()
        logging.debug('MySQL connection closed.')

print("Data migration completed successfully.")

import pandas as pd
import io
import datetime



excel_file = r"D:\Python 21 01 2025\ETO_Report_Final\Master Report - 06-02-2025.xlsx"
df1 = pd.read_excel(excel_file, sheet_name='Overall-C', header=6)

user_input = input("do you want save converted csv file (y/n :)")

if user_input == "y":
  csv_file_path = 'new.csv'
  df1.to_csv(csv_file_path, index=False)
else:
  print("continue")
#save csv to local variable
csv_buffer = io.BytesIO()
df1.to_csv(csv_buffer, index=False)
csv_buffer.seek(0)
df = pd.read_csv(csv_buffer)

# Step 4: Clean column names (strip spaces, replace newlines, lowercase for consistency)
df.columns = df.columns.str.strip()  # Remove leading/trailing spaces
df.columns = df.columns.str.replace(
    '\n', ' ', regex=True)  # Replace newline characters with spaces
df.columns = df.columns.str.lower()  # Convert to lowercase


# Step 5: Drop columns from 'AC' onwards
def excel_column_to_index(col_address):
  col_address = col_address.upper()
  column_index = 0
  for char in col_address:
    column_index = column_index * 26 + (ord(char) - ord('A') + 1)
  return column_index - 1


start_col_address = 'AC'
start_col_index = excel_column_to_index(start_col_address)
df = df.iloc[:, :start_col_index]

# Step 6: Drop additional specified columns
columns_to_drop = ['AB', 'Z', 'W', 'V', 'O', 'I', 'J', 'K', 'G', 'L']
columns_to_drop_indices = [
    excel_column_to_index(col) for col in columns_to_drop
]
df = df.drop(df.columns[columns_to_drop_indices], axis=1)

# Step 7: Add new columns 'location_name' and 'process_name'
df['location_name'] = 'Unknown'  # Default value
if 'process' in df.columns:
  df['process_name'] = df['process']
else:
  df['process_name'] = 'Unknown'

# Step 8: Map 'location_name' from 'location_code' using the provided dictionary
locations = {
    "KKND": "Kakkanad",
    "KNPY": "Karunagappally",
    "MDS": "Madurai",
    "MNS": "Madurai",
    "TSI": "Thenkasi",
    "TEN": "Tirunelveli",
    "MDSKG": "Madurai"
}
if 'location' in df.columns:  # Check if 'location_code' column exists
  df['location_name'] = df['location'].map(locations)

# Specify the columns to check
col1 = 'psn'  # First column to check
col2 = 'associates name'  # Second column to check
target_col = 'eto in usd'  # The column where you want to clear data from

# Loop through each row starting from the first row
for idx in range(len(df)):
  # Check if both columns (col1 and col2) are empty at the current row
  if pd.isna(df.at[idx, col1]) and pd.isna(df.at[idx, col2]):
    print(f"Both columns {col1} and {col2} are empty at row {idx}.")

    # Clear data in the target column starting from the current row onward
    df.loc[idx:, target_col] = None
    print(f"Cleared data in column {target_col} from row {idx} onwards.")
    break  # Exit the loop after clearing data once both columns are empty

else:
  # If the loop completes without finding both columns empty, print this message
  print(f"Both columns {col1} and {col2} were never empty in any row.")


# Step 10: Rename columns to the provided list
new_column_names = [
    'psn', 'associate_name', 'experience', 'process_name', 'project_name',
    'project_code', 'tl_name', 'actual_production', 'achievement_percent',
    'location_code', 'cr_date', 'target_revenue_inr', 'actual_revenue_inr',
    'revenue_achievement_percent', 'pe_code', 'eto_in_usd', 'manager', 'achieved_etos', 'location_name', 'process_code'
]


# Check if the length of new_column_names matches the number of columns
if len(new_column_names) == len(df.columns):
    df.columns = new_column_names
else:
    raise ValueError("The number of new column names does not match the number of columns in the DataFrame.")

# Step 11: Remove empty rows
df = df.dropna(how='all')  # Remove rows where all values are NaN

# Step 12: Replace NaN values based on the column's data type
for column in df.columns:
    if df[column].dtype == 'object':  # For string-like columns
        df[column] = df[column].fillna('None')
    elif pd.api.types.is_numeric_dtype(df[column]):  # For numeric columns
        df[column] = df[column].fillna('0')


column_to_convert = 'achievement_percent'  # Replace with the actual column name

# Convert decimal values to percentages (multiply by 100 and add % symbol)
df[column_to_convert] = df[column_to_convert].apply(lambda x: f"{int(x * 100)}" if pd.notna(x) else 'NULL')


column_to_convert = 'revenue_achievement_percent'  # Replace with the actual column name

# Convert decimal values to percentages (multiply by 100 and add % symbol)
df[column_to_convert] = df[column_to_convert].apply(lambda x: f"{int(x * 100)}" if pd.notna(x) else 'NULL')



column_to_convert = 'achieved_etos'  # Replace with the actual column name

# Convert decimal values to percentages (multiply by 100 and add % symbol)
df[column_to_convert] = df[column_to_convert].apply(lambda x: f"{int(x * 100)}" if pd.notna(x) else 'NULL')



column_name = 'cr_date'


# Function to convert a serial number to a date
def serial_to_date(serial_number):
    # First, ensure the serial_number is numeric and handle non-numeric values
    try:
        serial_number = float(serial_number)  # Convert to float in case it's a string like '45658'
    except ValueError:
        return None  # Return None or any other placeholder if the value is not numeric

    # Subtract 2 to account for Excel's leap year issue and convert serial number to date
    # Define base_date globally
    base_date = datetime.date(1899, 12, 30)
 
    converted_date = base_date + datetime.timedelta(days=serial_number - 2)
    return converted_date.strftime('%Y-%m-%d')

# Apply the conversion to the 'cr_date' column
df['ConvertedDate'] = df['cr_date'].apply(serial_to_date)




# Step 13: Save the cleaned DataFrame to a new Excel file
cr_date="cr_date"
print(df[cr_date])

# Specify the output file path

output_file = r"D:\Python 21 01 2025\ETO_Report_Final\output6_Mar.csv"
df.to_csv(output_file, index=False)
